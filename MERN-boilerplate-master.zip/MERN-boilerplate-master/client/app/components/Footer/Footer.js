import React from 'react';

const Footer = () => (
  <footer>
    <hr />
    <p>Footer</p>
  </footer>
);

export default Footer;
